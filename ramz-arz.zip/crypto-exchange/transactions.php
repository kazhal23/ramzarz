<?php
session_start();
require_once 'config/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit;
}
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>تاریخچه تراکنش‌ها</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
</head>
<body dir="rtl" class="container mt-5">
    <h2 class="mb-4">تاریخچه تراکنش‌ها</h2>
    <?php if (count($transactions) > 0): ?>
        <table class="table table-bordered text-center">
            <thead class="table-dark">
                <tr>
                    <th>نوع</th>
                    <th>ارز</th>
                    <th>مقدار</th>
                    <th>ارزش دلاری</th>
                    <th>تاریخ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transactions as $tx): ?>
                    <tr class="<?= $tx['type'] == 'buy' ? 'table-success' : 'table-danger' ?>">
                        <td><?= $tx['type'] == 'buy' ? 'خرید' : 'فروش' ?></td>
                        <td><?= strtoupper($tx['currency']) ?></td>
                        <td><?= $tx['amount'] ?></td>
                        <td><?= $tx['usd_value'] ?> $</td>
                        <td><?= $tx['created_at'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="alert alert-warning">تراکنشی ثبت نشده است.</div>
    <?php endif; ?>
    <a href="dashboard.php" class="btn btn-secondary mt-3">بازگشت به داشبورد</a>
</body>
</html>
