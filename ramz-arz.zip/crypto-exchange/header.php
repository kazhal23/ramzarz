<?php
if (session_status() === PHP_SESSION_NONE)
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>صرافی رمز ارز</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet" />
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
  <div class="container">
    <a class="navbar-brand" href="dashboard.php">صرافی رمز ارز</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
      aria-controls="navbarNav" aria-expanded="false" aria-label="نمایش منو">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="wallet.php">کیف پول</a></li>
        <li class="nav-item"><a class="nav-link" href="buy.php">خرید ارز</a></li>
        <li class="nav-item"><a class="nav-link" href="sell.php">فروش ارز</a></li>
        <li class="nav-item"><a class="nav-link" href="transactions.php">تاریخچه تراکنش‌ها</a></li>
      </ul>
      <span class="navbar-text text-light">
        سلام <?= htmlspecialchars($_SESSION['username'] ?? 'کاربر') ?>
      </span>
    </div>
  </div>
</nav>
<div class="container">
