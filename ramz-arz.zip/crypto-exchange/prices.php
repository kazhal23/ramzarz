<?php
$api_url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,tether&vs_currencies=usd";
$response = file_get_contents($api_url);
$data = json_decode($response, true);
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <title>قیمت لحظه‌ای ارزها</title>
</head>
<body dir="rtl">
    <h2>قیمت لحظه‌ای رمزارزها</h2>
    <table border="1">
        <tr>
            <th>ارز</th>
            <th>قیمت (دلار)</th>
        </tr>
        <tr>
            <td>بیت‌کوین (BTC)</td>
            <td><?php echo $data['bitcoin']['usd']; ?> $</td>
        </tr>
        <tr>
            <td>اتریوم (ETH)</td>
            <td><?php echo $data['ethereum']['usd']; ?> $</td>
        </tr>
        <tr>
            <td>تتر (USDT)</td>
            <td><?php echo $data['tether']['usd']; ?> $</td>
        </tr>
    </table>
    <p><a href="dashboard.php">بازگشت به داشبورد</a></p>
</body>
</html>
