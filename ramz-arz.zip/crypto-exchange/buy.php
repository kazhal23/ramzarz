<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include 'config/db.php';
$errors = [];
$success = "";
$prices = fetchCryptoPrices();
if (!$prices) {
    $errors[] = "دریافت قیمت ارزها ناموفق بود.";
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currency = $_POST['crypto'] ?? '';
    $amount_usd = floatval($_POST['amount_usd'] ?? 0);
    $valid_currencies = ['bitcoin', 'ethereum', 'tether'];
    if (!in_array($currency, $valid_currencies)) {
        $errors[] = "ارز انتخاب شده معتبر نیست.";
    }
    if ($amount_usd <= 0) {
        $errors[] = "مقدار باید بیشتر از صفر باشد.";
    }
    if (empty($errors) && isset($prices[$currency]['usd'])) {
    $crypto_price = $prices[$currency]['usd'];
    $amount_crypto = $amount_usd / $crypto_price;
    $stmt = $pdo->prepare("SELECT * FROM wallets WHERE user_id = ? AND currency = ?");
    $stmt->execute([$_SESSION['user_id'], $currency]);
    $wallet = $stmt->fetch();
    if ($wallet) {
        $stmt = $pdo->prepare("UPDATE wallets SET balance = balance + ? WHERE id = ?");
        $stmt->execute([$amount_crypto, $wallet['id']]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO wallets (user_id, currency, balance) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $currency, $amount_crypto]);
    }
    $total_price = $amount_crypto * $crypto_price;

    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, currency, amount, type, price_per_unit, total_price, created_at) VALUES (?, ?, ?, 'buy', ?, ?, NOW())");
    $stmt->execute([$_SESSION['user_id'], $currency, $amount_crypto, $crypto_price, $total_price]);
    $success = "خرید با موفقیت انجام شد.";
}
}
function fetchCryptoPrices() {
    $url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,tether&vs_currencies=usd";
    $curl = curl_init($url);
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false
    ]);
    $response = curl_exec($curl);
    curl_close($curl);
    return json_decode($response, true);
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>خرید ارز دیجیتال</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>
<?php include 'header.php'; ?>
<div class="container mt-5">
    <h2>خرید ارز دیجیتال</h2>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <form method="post" class="mt-4">
        <div class="mb-3">
            <label for="crypto" class="form-label">ارز مورد نظر:</label>
            <select name="crypto" id="crypto" class="form-select">
                <option value="bitcoin">بیت‌کوین</option>
                <option value="ethereum">اتریوم</option>
                <option value="tether">تتر</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="amount_usd" class="form-label">مقدار (دلار):</label>
            <input type="number" step="0.01" name="amount_usd" id="amount_usd" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">خرید</button>
        <p class="mt-3"><a href="dashboard.php" class="btn btn-secondary">بازگشت به داشبورد</a></p>
    </form>
</div>
</body>
</html>
