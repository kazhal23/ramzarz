<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            text-align: center;
        }
        .dashboard-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 90%;
        }
        .dashboard-box h3 {
            font-size: 22px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .btn-logout {
            width: 100%;
            font-size: 16px;
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="dashboard-box">
        <h3>👋 سلام، <?php echo $_SESSION['user_name']; ?>! خوش آمدید</h3>
        <a href="../process/logout.php" class="btn btn-danger btn-logout">🚪 خروج از سیستم</a>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
