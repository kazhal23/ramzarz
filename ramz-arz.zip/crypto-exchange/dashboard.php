<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
 <meta charset="UTF-8">
	<meta name="description" content="Cryptocurrency Landing Page Template">
	<meta name="keywords" content="cryptocurrency, unica, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="img/favicon.ico" rel="shortcut icon"/>
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/themify-icons.css"/>
	<link rel="stylesheet" href="css/animate.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>

	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
  <title>داشبورد</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet" />
</head>
<body class="bg-light">
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
      <a class="navbar-brand" href="#">صرافی رمز ارز</a>
      <div>
        <a href="wallet.php" class="btn btn-outline-light me-2">کیف پول</a>
        <a href="buy.php" class="btn btn-outline-light me-2">خرید ارز</a>
        <a href="sell.php" class="btn btn-outline-light me-2">فروش ارز</a>
        <a href="transactions.php" class="btn btn-outline-light">تاریخچه تراکنش‌ها</a>
        <a href="logout.php" class="btn btn-warning">خروج</a>

      </div>
    </div>
  </nav>

  <main class="container">
<h1 class="mb-4">سلام <?= isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'کاربر' ?> عزیز، خوش آمدید!</h1>

<section class="hero-section">
		<div class="container">
			<div class="row">
				<div class="col-md-6 hero-text">
					<h2><span>بیتکوین</span> <br>تجارت با بیت کوین</h2>
					<h4>برای کسب درآمد از فناوری های پیشرفته پیشروی بیت کوین استفاده کنید</h4>
				</div>
				<div class="col-md-6">
					<img src="img/laptop.png" class="laptop-image" alt="">
				</div>
			</div>
		</div>
	</section>
	<!-- Hero section end -->


	<!-- About section -->
	<section class="about-section spad" dir="ltr">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 offset-lg-6 about-text">
					<h2>بیت کوین چیست؟</h2>
					<h5>بیت کوین یک شبکه پرداخت نوآورانه و نوع جدیدی از پول است.</h5>
					<p>بیت کوین یکی از مهمترین اختراعات تاریخ بشر است. برای اولین بار، هر کسی می تواند هر مقدار پول را با هرکس دیگری، در هر نقطه از کره زمین، به راحتی و بدون محدودیت ارسال یا دریافت کند. این طلوع یک دنیای بهتر و آزادتر است.</p>
					<a href="auth/register.php" class="site-btn sb-gradients sbg-line mt-5">همین حالا برای اطلاعات بیشتر ثبت نام کنید</a>
				</div>
			</div>
			<div class="about-img" >
				<img src="img/about-img.png" alt="">
			</div>
		</div>
	</section>
	<!-- About section end -->


	<!-- Features section -->
	<section class="features-section spad gradient-bg">
	<div class="container text-white">
		<div class="section-title text-center">
			<h2>ویژگی‌های ما</h2>
			<p>بیت‌کوین ساده‌ترین راه برای مبادله پول با هزینه بسیار کم است.</p>
		</div>
		<div class="row">
			<!-- feature item -->
			<div class="col-md-6 col-lg-4 feature d-flex align-items-start mb-4">
				<i class="ti-mobile display-5 me-3 mt-1"></i>
				<div class="feature-content">
					<h4>برنامه‌های موبایل</h4>
					<a href="#" class="readmore">بیشتر بدانید</a>
				</div>
			</div>

			<div class="col-md-6 col-lg-4 feature d-flex align-items-start mb-4">
				<i class="ti-shield display-5 me-3 mt-1"></i>
				<div class="feature-content">
					<h4>امنیت و ایمنی</h4>
					<a href="#" class="readmore">بیشتر بدانید</a>
				</div>
			</div>

			<div class="col-md-6 col-lg-4 feature d-flex align-items-start mb-4">
				<i class="ti-wallet display-5 me-3 mt-1"></i>
				<div class="feature-content">
					<h4>کیف پول</h4>
					<a href="#" class="readmore">بیشتر بدانید</a>
				</div>
			</div>

			<div class="col-md-6 col-lg-4 feature d-flex align-items-start mb-4">
				<i class="ti-headphone-alt display-5 me-3 mt-1"></i>
				<div class="feature-content">
					<h4>پشتیبانی</h4>
					<a href="#" class="readmore">بیشتر بدانید</a>
				</div>
			</div>

			<div class="col-md-6 col-lg-4 feature d-flex align-items-start mb-4">
				<i class="ti-reload display-5 me-3 mt-1"></i>
				<div class="feature-content">
					<h4>تبادل فوری</h4>
					<a href="#" class="readmore">بیشتر بدانید</a>
				</div>
			</div>

			<div class="col-md-6 col-lg-4 feature d-flex align-items-start mb-4">
				<i class="ti-panel display-5 me-3 mt-1"></i>
				<div class="feature-content">
					<h4>خریدهای مکرر</h4>
					<a href="#" class="readmore">بیشتر بدانید</a>
				</div>
			</div>
		</div>
	</div>
</section>

	<!-- Features section end -->


	<!-- Process section -->
	<section class="process-section spad" dir="rtl">
	<div class="container">
		<div class="section-title text-center">
			<h2>شروع با بیت‌کوین</h2>
			<p>یادگیری بیت‌کوین را با آموزش‌های تعاملی آغاز کنید. این کار سرگرم‌کننده، آسان و فقط چند دقیقه زمان می‌برد!</p>
		</div>
		<div class="row">
			<div class="col-md-4 process">
				<div class="process-step text-center">
					<figure class="process-icon">
						<img src="img/process-icons/1.png" alt="#">
					</figure>
					<h4>کیف پول خود را بسازید</h4>
					<p>با ساخت کیف پول دیجیتال، اولین قدم خود را برای ورود به دنیای ارزهای دیجیتال بردارید.</p>
				</div>
			</div>
			<div class="col-md-4 process">
				<div class="process-step text-center">
					<figure class="process-icon">
						<img src="img/process-icons/2.png" alt="#">
					</figure>
					<h4>ارز دیجیتال بخرید</h4>
					<p>به راحتی و با چند کلیک می‌توانید بیت‌کوین و سایر ارزهای دیجیتال را خریداری کنید.</p>
				</div>
			</div>
			<div class="col-md-4 process">
				<div class="process-step text-center">
					<figure class="process-icon">
						<img src="img/process-icons/3.png" alt="#">
					</figure>
					<h4>تراکنش انجام دهید</h4>
					<p>اکنون می‌توانید ارزهای دیجیتال خود را ارسال، دریافت و مدیریت کنید.</p>
				</div>
			</div>
		</div>
	</div>
</section>

	<!-- Process section end -->


	<!-- بخش آمار -->
<section class="fact-section gradient-bg text-white" dir="rtl">
	<div class="container">
		<div class="row text-center">
			<div class="col-sm-6 col-md-6 col-lg-3">
				<div class="fact">
					<h2>۶۰</h2>
					<p>کشورهای<br> پشتیبانی‌شده</p>
					<i class="ti-basketball"></i>
				</div>
			</div>
			<div class="col-sm-6 col-md-6 col-lg-3">
				<div class="fact">
					<h2>۱۲K</h2>
					<p>تراکنش‌ها<br> در هر ساعت</p>
					<i class="ti-panel"></i>
				</div>
			</div>
			<div class="col-sm-6 col-md-6 col-lg-3">
				<div class="fact">
					<h2>۵B</h2>
					<p>بزرگ‌ترین<br> تراکنش‌ها</p>
					<i class="ti-stats-up"></i>
				</div>
			</div>
			<div class="col-sm-6 col-md-6 col-lg-3">
				<div class="fact">
					<h2>۲۴۰</h2>
					<p>سال‌ها<br> تجربه</p>
					<i class="ti-user"></i>
				</div>
			</div>
		</div>
	</div>
</section>

    <div class="alert alert-info">
      قیمت‌های لحظه‌ای ارزها در اینجا نمایش داده می‌شود.
    </div>
    

  </main>
</body>
</html>

