<?php
session_start();
require_once 'config/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit;
}
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT currency, balance FROM wallets WHERE user_id = ?");
$stmt->execute([$user_id]);
$wallet = $stmt->fetchAll(PDO::FETCH_ASSOC);
$api_url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,tether&vs_currencies=usd";
$response = file_get_contents($api_url);
$prices = json_decode($response, true);
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <title>کیف پول</title>
</head>
<body dir="rtl">
    <?php include 'header.php'; ?>
    <div class="container mt-5">
        <h2 class="mb-4">کیف پول شما</h2>
        <?php if ($wallet): ?>
        <table class="table table-striped table-bordered">
          <thead class="table-primary">
            <tr>
              <th>نام ارز</th>
              <th>مقدار</th>
              <th>ارزش تقریبی به دلار</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($wallet as $row): 
                $currency = $row['currency'];
                $amount = $row['balance'];
                $usd_value = isset($prices[$currency]['usd']) ? $amount * $prices[$currency]['usd'] : 0;
            ?>
            <tr>
                <td><?= htmlspecialchars($currency) ?></td>
                <td><?= htmlspecialchars($amount) ?></td>
                <td>$<?= number_format($usd_value, 2) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <?php else: ?>
            <p>هیچ ارز دیجیتالی ندارید.</p>
        <?php endif; ?>

        <p class="mt-4"><a href="dashboard.php" class="btn btn-secondary">بازگشت به داشبورد</a></p>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>
