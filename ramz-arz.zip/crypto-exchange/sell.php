<?php
session_start();
require_once 'config/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit;
}
$user_id = $_SESSION['user_id'];
$errors = [];
$success = "";
$api_url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,tether&vs_currencies=usd";
$response = file_get_contents($api_url);
$prices = json_decode($response, true);
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $currency = $_POST['crypto']; 
    $amount_crypto = floatval($_POST['amount']);

    if (!$currency || $amount_crypto <= 0) {
        $errors[] = "اطلاعات فروش نامعتبر است.";
    } else {
        $stmt = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ? AND currency = ?");
        $stmt->execute([$user_id, $currency]);
        $wallet = $stmt->fetch();
        if (!$wallet || $wallet['balance'] < $amount_crypto) {
            $errors[] = "موجودی کافی برای فروش ندارید.";
        } else {
            $price = $prices[$currency]['usd'];
            $usd_value = $amount_crypto * $price;

            $stmt = $pdo->prepare("UPDATE wallets SET balance = balance - ? WHERE user_id = ? AND currency = ?");
            $stmt->execute([$amount_crypto, $user_id, $currency]);

            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, type, currency, amount, usd_value) VALUES (?, 'sell', ?, ?, ?)");
            $stmt->execute([$user_id, $currency, $amount_crypto, $usd_value]);

            $success = "فروش با موفقیت انجام شد: $amount_crypto واحد $currency به مبلغ $usd_value دلار";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <title>فروش ارز دیجیتال</title>
</head>
<body dir="rtl">
    <h2>فروش ارز دیجیتال</h2>
    <?php foreach ($errors as $error): ?>
        <p style="color:red;"><?= $error ?></p>
    <?php endforeach; ?>

    <?php if ($success): ?>
        <p style="color:green;"><?= $success ?></p>
    <?php endif; ?>

   <?php include 'header.php'; ?>
<h2 class="mb-4">فروش ارز دیجیتال</h2>
<form action="sell.php" method="post" class="needs-validation" novalidate>
  <div class="mb-3">
    <label for="crypto" class="form-label">انتخاب ارز</label>
    <select id="crypto" name="crypto" class="form-select" required>
      <option value="" disabled selected>یک ارز انتخاب کنید</option>
      <option value="bitcoin">بیت کوین</option>
      <option value="ethereum">اتریوم</option>
      <option value="tether">تتر</option>
    </select>
    <div class="invalid-feedback">
      لطفا یک ارز معتبر انتخاب کنید.
    </div>
  </div>
  <div class="mb-3">
    <label for="amount" class="form-label">مقدار فروش (تعداد کوین)</label>
    <input type="number" class="form-control" id="amount" name="amount" min="0.0001" step="0.0001" required>
    <div class="invalid-feedback">
      مقدار فروش باید عدد مثبت و معتبر باشد.
    </div>
  </div>
  <button type="submit" class="btn btn-danger">فروش</button>
</form>
<script>
(() => {
  'use strict';
  const forms = document.querySelectorAll('.needs-validation');
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });
})();
</script>
<?php include 'footer.php'; ?>
    <p class="mt-3"><a href="dashboard.php" class="btn btn-secondary">بازگشت به داشبورد</a></p>
</body>
</html>
