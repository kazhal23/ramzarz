<?php
session_start();
include('../config/db.php');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("❌ دسترسی غیرمجاز!");
}
if (empty($_SESSION['reset_email'])) {
    die("❌ دسترسی غیرمجاز! ایمیل در سشن نیست.");
}
if (!isset($_POST['password']) || !isset($_POST['confirm_password'])) {
    die("❌ لطفاً همه فیلدها را پر کنید.");
}
$password = trim($_POST['password']);
$confirm_password = trim($_POST['confirm_password']);
if ($password !== $confirm_password) {
    die("❌ رمز عبور و تکرار آن یکسان نیستند!");
}
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
if ($hashed_password === false) {
    die("❌ خطا در هش کردن رمز عبور!");
}
$email = $_SESSION['reset_email'];
var_dump($email);
var_dump($hashed_password);
$stmt = $conn->prepare("UPDATE users SET password = ?, reset_code = NULL WHERE email = ?");
if (!$stmt) {
    die("❌ خطا در آماده‌سازی کوئری: " . $conn->error);
}
$stmt->bind_param("ss", $hashed_password, $email);
if ($stmt->execute()) {
    if ($stmt->affected_rows === 0) {
        die("❌ هیچ ردیفی به‌روزرسانی نشد! ممکن است ایمیل موجود نباشد.");
    }
    unset($_SESSION['reset_email']);
    unset($_SESSION['reset_code']);
    unset($_SESSION['reset_user_id']);
    $stmt->close();
    $conn->close();
    header("Location: login.php?success=1");
    exit;
} else {
    die("❌ خطا در به‌روزرسانی رمز عبور: " . $stmt->error);
}
?>
