<?php
session_start();
include('../config/db.php');
require '../libs/PHPMailer/PHPMailer.php';
require '../libs/PHPMailer/SMTP.php';
require '../libs/PHPMailer/Exception.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("❌ متد درخواست باید POST باشد.");
}
if (!isset($_POST['email']) || empty(trim($_POST['email']))) {
    die("❌ ایمیل ارسال نشده یا خالی است.");
}
$email = trim($_POST['email']);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("❌ فرمت ایمیل معتبر نیست.");
}
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
if (!$stmt) die("❌ خطا در آماده‌سازی کوئری: " . $conn->error);
$stmt->bind_param("s", $email);
if (!$stmt->execute()) die("❌ خطا در اجرای کوئری: " . $stmt->error);
$result = $stmt->get_result();
if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $reset_code = strval(rand(1000, 9999));
    $_SESSION['reset_email'] = $email;
    $_SESSION['reset_code'] = $reset_code;
    $_SESSION['reset_user_id'] = $user['id'];
    $update = $conn->prepare("UPDATE users SET reset_code = ? WHERE id = ?");
    if (!$update) die("❌ خطا در آماده‌سازی کوئری آپدیت: " . $conn->error);
    $update->bind_param("si", $reset_code, $user['id']);
    if (!$update->execute()) die("❌ خطا در اجرای کوئری آپدیت: " . $update->error);
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = '';
        $mail->SMTPAuth = true;
        $mail->Username = '';
        $mail->Password = '';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->setFrom('', '');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'کد بازیابی رمز عبور';
        $mail->Body = "کد شما برای بازیابی رمز عبور: <b>$reset_code</b>";
        $mail->send();
        $stmt->close();
        $update->close();
        $conn->close();
        header("Location: verify_code.php");
        exit;
    } catch (Exception $e) {
        die("❌ خطا در ارسال ایمیل: {$mail->ErrorInfo}");
    }
} else {
    die("❌ ایمیل وارد شده در سیستم ثبت نشده است.");
}
?>
