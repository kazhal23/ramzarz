<?php
session_start();
include('../config/db.php');
ini_set('display_errors', 1);
error_reporting(E_ALL);
$login_message = '';
if (isset($_SESSION['user_id'])) {
    header("Location: ../dashboard.php");
    exit;
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $email = htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8');
    $password = htmlspecialchars($_POST['password'], ENT_QUOTES, 'UTF-8');
    if (empty($email) || empty($password)) {
        $login_message = "❌ لطفاً تمام فیلدها را پر کنید.";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user) {
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                header("Location: ../dashboard");
                exit;
            } else {
                $login_message = "❌ رمز عبور اشتباه است.";
            }
        } else {
            $login_message = "❌ این ایمیل وجود ندارد.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 90%;
        }
        .login-box h2 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .btn-login {
            width: 100%;
            font-size: 16px;
            padding: 10px;
        }
        .text-danger {
            font-size: 14px;
        }
        .form-label {
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2 class="text-center">ورود</h2>
        <form method="POST" action="login.php">
            <div class="mb-3">
                <label for="email" class="form-label">ایمیل:</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">رمز عبور:</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" name="login" class="btn btn-primary btn-login">ورود</button>
            <p class="text-center mt-3">
                حساب ندارید؟ <a href="register.php">ثبت‌نام</a>
            </p>
            <p class="text-center mt-3">
                فراموش کرده‌اید؟ <a href="../auth/request_reset.php">بازیابی رمز عبور</a>
            </p>
        </form>
        <p class="text-danger text-center mt-3">
            <?php echo $login_message; ?>
        </p>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>