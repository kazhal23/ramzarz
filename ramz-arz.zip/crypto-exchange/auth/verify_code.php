<?php
session_start();
include('../config/db.php');
$error = '';
if (!isset($_SESSION['reset_code']) || !isset($_SESSION['reset_email'])) {
    $error = "❌ اطلاعات جلسه منقضی شده است. لطفاً مجدداً درخواست بازیابی رمز را ارسال کنید.";
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && empty($error)) {
    $code = trim($_POST['code']);

    if ($code === (string)$_SESSION['reset_code']) {
        $_SESSION['reset_verified'] = true;
        header("Location: new_password.php");
        exit;
    } else {
        $error = "❌ کد اشتباه است.";
    }
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>تأیید کد بازیابی</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body dir="rtl">
<div class="container mt-4">
    <h2>🔢 تأیید کد بازیابی</h2>
    <?php if (!empty($error)) : ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST" autocomplete="off">
        <div class="mb-3">
            <label>کد:</label>
            <input type="text" name="code" class="form-control" required autofocus>
        </div>
        <button type="submit" class="btn btn-success">✅ تأیید</button>
    </form>
</div>
</body>
</html>
