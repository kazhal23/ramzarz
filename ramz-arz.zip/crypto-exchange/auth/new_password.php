<?php
session_start();
include('../config/db.php');
$error = '';
if (!isset($_SESSION['reset_email'])) {
    header("Location: request_reset.php");
    exit;
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $password = trim($_POST['password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');
    if ($password === '' || $confirm_password === '') {
        $error = "❌ لطفاً همه فیلدها را کامل پر کنید.";
    } elseif ($password !== $confirm_password) {
        $error = "❌ رمز عبور و تکرار آن یکسان نیستند.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $email = $_SESSION['reset_email'];
        try {
            $stmt = $pdo->prepare("UPDATE users SET password = ?, reset_code = NULL WHERE email = ?");
            $stmt->execute([$hashed_password, $email]);
            unset($_SESSION['reset_email'], $_SESSION['reset_code']);
            header("Location: login.php");
            exit;
        } catch (PDOException $e) {
            $error = "❌ خطا در به‌روزرسانی رمز عبور. لطفاً مجدداً تلاش کنید.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>تنظیم رمز جدید</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .reset-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 90%;
            text-align: center;
        }
        .reset-box h2 {
            font-size: 22px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .btn-save {
            width: 100%;
            font-size: 16px;
            padding: 10px;
        }
    </style>
</head>
<body>
<div class="reset-box">
    <h2>🔐 تنظیم رمز جدید</h2>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="mb-3 text-start">
            <label for="password" class="form-label">رمز جدید:</label>
            <input type="password" id="password" name="password" class="form-control" required autocomplete="new-password" />
        </div>
        <div class="mb-3 text-start">
            <label for="confirm_password" class="form-label">تکرار رمز:</label>
            <input type="password" id="confirm_password" name="confirm_password" class="form-control" required autocomplete="new-password" />
        </div>
        <button type="submit" class="btn btn-primary btn-save">✅ ذخیره رمز جدید</button>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
