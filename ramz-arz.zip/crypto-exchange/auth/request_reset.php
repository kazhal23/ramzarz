<?php
session_start();
include('../config/db.php');
ini_set('display_errors', 1);
error_reporting(E_ALL);
$error = '';
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email']);
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "❌ لطفاً یک ایمیل معتبر وارد کنید.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            $reset_code = rand(100000, 999999);
            $update = $pdo->prepare("UPDATE users SET reset_code = ? WHERE id = ?");
            $update->execute([$reset_code, $user['id']]);
            $subject = "کد بازیابی رمز عبور";
            $message = "کد شما برای بازیابی رمز عبور:\n\n$reset_code";
            $headers = "From:\r\nContent-Type: text/plain; charset=UTF-8";
            if (mail($email, $subject, $message, $headers)) {
                $_SESSION['reset_email'] = $email;
                $_SESSION['reset_code'] = $reset_code;
                $_SESSION['reset_user_id'] = $user['id'];
                header("Location: verify_code.php");
                exit;
            } else {
                $error = "❌ خطا در ارسال ایمیل. لطفاً مجدداً تلاش کنید.";
            }
        } else {
            $error = "❌ ایمیل وارد شده در سیستم ثبت نشده است.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>بازیابی رمز عبور</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body dir="rtl">
<div class="container mt-5" style="max-width: 500px;">
    <h3 class="mb-4">🔑 بازیابی رمز عبور</h3>
    <?php if (!empty($error)) : ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
    <form method="POST" novalidate>
        <div class="mb-3">
            <label for="email" class="form-label">ایمیل:</label>
            <input type="email" name="email" id="email" class="form-control" required placeholder="example@mail.com">
        </div>
        <button type="submit" class="btn btn-primary">📩 ارسال کد</button>
    </form>
</div>
</body>
</html>
