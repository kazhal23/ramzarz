<?php
session_start();
include('../config/db.php');
ini_set('display_errors', 1);
error_reporting(E_ALL);
$registration_message = '';
if (isset($_SESSION['user_id'])) {
    header('Location: ../dashboard.php');
    exit;
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $fullname = trim(htmlspecialchars($_POST['fullname'] ?? '', ENT_QUOTES, 'UTF-8'));
    $name = trim(htmlspecialchars($_POST['name'] ?? '', ENT_QUOTES, 'UTF-8'));
    $email = trim(htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8'));
    $password = trim($_POST['password'] ?? '');
    if (empty($fullname) || empty($name) || empty($email) || empty($password)) {
        $registration_message = "❌ لطفاً تمام فیلدها را پر کنید.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $registration_message = "❌ ایمیل نامعتبر است.";
    } else {
        $checkEmail = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $checkEmail->execute([$email]);
        $user = $checkEmail->fetch();
        if ($user) {
            $registration_message = "❌ این ایمیل قبلاً ثبت شده است.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (fullname, name, email, password) VALUES (?, ?, ?, ?)");
            $result = $stmt->execute([$fullname, $name, $email, $hashed_password]);
            if ($result) {
                header('Location: login.php?registered=1');
                exit;
            } else {
                $registration_message = "❌ خطا در ثبت اطلاعات، لطفاً دوباره تلاش کنید.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>ثبت‌نام</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .register-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            max-width: 400px;
            width: 90%;
        }
        .register-box h2 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .btn-register {
            width: 100%;
            font-size: 16px;
            padding: 10px;
        }
        .text-danger {
            font-size: 14px;
        }
        .form-label {
            font-size: 14px;
        }
    </style>
</head>
<body>
<div class="register-box">
    <h2 class="text-center">ثبت‌نام</h2>
    <form method="POST" action="register.php" dir="rtl">
        <div class="mb-3">
            <label for="fullname" class="form-label">نام کامل:</label>
            <input type="text" name="fullname" class="form-control" required />
        </div>
        <div class="mb-3">
            <label for="name" class="form-label">نام:</label>
            <input type="text" name="name" class="form-control" required />
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">ایمیل:</label>
            <input type="email" name="email" class="form-control" required />
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">رمز عبور:</label>
            <input type="password" name="password" class="form-control" required />
        </div>
        <button type="submit" name="register" class="btn btn-success btn-register">ثبت‌نام</button>
        <p class="text-center mt-3">
            قبلاً ثبت‌نام کرده‌اید؟ <a href="login.php">ورود</a>
        </p>
    </form>
    <p class="text-danger text-center mt-3">
        <?php echo $registration_message; ?>
    </p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
